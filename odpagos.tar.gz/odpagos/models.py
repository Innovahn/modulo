# -*- coding: utf-8 -*-

from openerp import models, fields, api
from datetime import datetime
from dateutil.relativedelta import relativedelta
from openerp.tools.translate import _

class mcheck(models.Model):
	_name = 'mcheck.opagos'

	order_id = fields.Many2one('orden_pagos',string="ordenes")
	reference		= fields.Char(string="Referencia",help="Referencia de la orden")
	name			= fields.Text()
	total			= fields.Float(string='Saldo')
	date			= fields.Date('Fecha',help="Fecha de aprobacion")
	journal_id		= fields.Many2one('account.journal',string="Journal ", help="Journal")
	mcheck_id		= fields.Many2one('mcheck.mcheck',string="Mcheck Ref")
	doc_type		= fields.Selection([('check', 'Mcheck'),('transference', 'Transference'),], 
							'Doc Type', select=True, copy=False, default= 'check',)
	


	'''
	@api.multi
	def unlink(self):
		raise osv.except_osv(_('Error!'),_("You can not Delete this document") )'''
	
	@api.multi
	def open_check(self):
		dummy, view_id_form  = self.pool.get('ir.model.data').get_object_reference(self.env.cr, self.env.uid, 'banks', 'view_mcheck_form')
		valores = {}
		valores = dict(valores or {})
		valores.update({'doc_type': self.doc_type,'journal_id': self.journal_id.id,'name': self.name, 'reference': self.reference, 'total': self.total})
		if self.mcheck_id:
			chq = self.env["mcheck.mcheck"].browse(self.mcheck_id.id)
			chq.write(valores)
			return {
				'name':_("Mchecks"),
				'view_type': 'form',
			   	'res_model': 'mcheck.mcheck',
			    	'type': 'ir.actions.act_window',
				'context': {},
				'views': [(view_id_form, 'form')],
				'nodestroy': True,
				'res_id' : self.mcheck_id.id,
			    	'target': 'current',
			    	'domain': '[]'
				}
		else:
			b = self.env["mcheck.mcheck"].create(valores)
			if b:
				self.write({'mcheck_id': b.id})
				return {
					'name':_("Mchecks"),
					'view_type': 'form',
				   	'res_model': 'mcheck.mcheck',
				    	'type': 'ir.actions.act_window',
					'context': {},
					'views': [(view_id_form, 'form')],
					'nodestroy': True,
					'res_id' : b.id,
				    	'target': 'current',
				    	'domain': '[]'
					}
			
			

class mcheck(models.Model):
	_inherit = 'mcheck.mcheck'

	order_id = fields.Many2one('orden_pagos',string="ordenes")
	@api.multi
	def open_check(self):
		dummy, view_id_form  = self.pool.get('ir.model.data').get_object_reference(self.env.cr, self.env.uid, 'banks', 'view_mcheck_form')
		return {
			'name':_("Mchecks"),
			'view_type': 'form',
		   	'res_model': 'mcheck.mcheck',
		    	'type': 'ir.actions.act_window',
			'context': {},
			'views': [(view_id_form, 'form')],
			'nodestroy': True,
			'res_id' : self.id,
		    	'target': 'current',
		    	'domain': '[]'
			}

class factura(models.Model):
	_inherit = 'account.invoice'




	
	orden_id = fields.Many2one('orden_pagos',string="ordenes")
	state	 = fields.Selection([
			    ('draft','Draft'),
			    ('open','Open'),
			    ('solicitud_pago','Solicitud de Pago'),
			    ('validacion_pago','Pago Aprobado'),
			    ('proforma','Pro-forma'),
			    ('proforma2','Pro-forma'),
			    ('paid','Paid'),
			    ('cancel','Cancelled'),
			], string='Status', index=True, readonly=True, default='draft',
			track_visibility='onchange', copy=False,
			help=" * The 'Draft' status is used when a user is encoding a new and unconfirmed Invoice.\n"
			     " * The 'Pro-forma' when invoice is in Pro-forma status,invoice does not have an invoice number.\n"
			     " * The 'Open' status is used when user create invoice,a invoice number is generated.Its in open status till user does not pay invoice.\n"
			     " * The 'Paid' status is set automatically when the invoice is paid. Its related journal entries may or may not be reconciled.\n"
			     " * The 'Cancelled' status is used when user cancel invoice.")


	@api.one
	def confirmar_pago(self):
		flag=False
		for invoice in self:
			invoice.state="validacion_pago"
			for orden in self.orden_id:
				for invoices in orden.facturas3:
					if invoices.state=='validacion_pago':
						flag=True
					else:
						flag=False
						break
				if flag==True:
					orden.state='done'
			
	

	
	
			



class orden_pagos(models.Model):
     	_name = 'orden_pagos'

	name			= fields.Char(string="Referencia", help="Referencia de la orden")
	description		= fields.Text()
	is_group_manager	= fields.Boolean(compute = 'obt_group' ,string="grupo",type="boolean")
	fecha_aprobacion	= fields.Date('Fecha de Aprobacion',help="Fecha de aprobacion")
	fecha_confirmacion 	= fields.Date('Fecha de Solicitud',help="Fecha de Confirmacion")
	
	responsable		= fields.Many2one('res.users',string="Responsable", default=lambda self: self.env.user, help="Responsable de la creacion de ordenes de pago")
	aprobed_by		= fields.Many2one('res.users',string="Aprobado por", help="Responsable de la aprobación de ordenes de pago")
	facturas3		= fields.One2many('account.invoice','orden_id',string="Facturas")
	mchecks			= fields.One2many('mcheck.opagos','order_id',string="Mchecks")
	total			= fields.Float(compute = '_compute_total', string='Saldo')
	checks_total		= fields.Float(compute = '_compute_checks_total', string='Saldo')
	description		= fields.Text(string='Descripción')
	state			= fields.Selection([
        	('draft', 'Borrador'),
            	('cancel', 'Cancelado'),
            	('open', 'Confirmado'),
            	('done', 'Finalizado')], 'Status', select=True, copy=False, default= 'draft',
           	 help='Cuando la orden es creada esta en estado \'Borrador\'.\n una vez confirmado el estado cambia a \'Confirmado\'.\n Luego la orden es validada y pasa al estado \'Finalizado\'.')
	
	@api.depends('facturas3.residual')
	def _compute_total(self):
		for record in self:
        		record.total = sum(line.residual for line in record.facturas3)
	

	@api.depends('mchecks.total')
	def _compute_checks_total(self):
		for record in self:
        		record.checks_total = sum(line.total for line in record.mchecks)

	def obt_group(self):
		res={}
		obj_group_ids = self.env['res.groups'].search([('name','=','Ordenes de pago')])
		
		for orden in self:
			for user in obj_group_ids.users:
				if self._uid==user.id:
					res[orden.id] = True
					self.is_group_manager=res
					break
				else:	
					res[orden.id] = False
			
			
		return res
	@api.one
	def borrador(self):
		self.state = "draft"

	#@api.multi
	@api.one	# para recorrer la colección
	def solicitar_pago(self): #,cr,uid,ids,context=None):
		self.fecha_confirmacion = datetime.today() -relativedelta(hours=6)
		for line in self.facturas3:
			line.state ="solicitud_pago"
		secuencia = self.env['ir.sequence'].get('secuencia_orden_pago')
		self.name = secuencia
		self.state = "open"


	@api.one
	def confirmar_pago(self):
		for invoice in self.facturas3:
			invoice.state="validacion_pago"
		self.fecha_aprobacion = datetime.today() -relativedelta(hours=6)
		self.state = "done"
		self.aprobed_by = self.env.user


	





