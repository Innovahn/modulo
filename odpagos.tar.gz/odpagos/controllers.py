# -*- coding: utf-8 -*-
from openerp import http

# class Odpagos(http.Controller):
#     @http.route('/odpagos/odpagos/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/odpagos/odpagos/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('odpagos.listing', {
#             'root': '/odpagos/odpagos',
#             'objects': http.request.env['odpagos.odpagos'].search([]),
#         })

#     @http.route('/odpagos/odpagos/objects/<model("odpagos.odpagos"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('odpagos.object', {
#             'object': obj
#         })