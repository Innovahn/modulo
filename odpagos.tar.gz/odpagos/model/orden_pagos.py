# -*- coding: utf-8 -*-

from openerp.osv import fields, osv
from openerp.tools.translate import _
from datetime import datetime
from dateutil.relativedelta import relativedelta
class orden_pagos(osv.Model):




	def solicitar_pago(self,cr,uid,ids,context=None):
		for orden in self.browse(cr,uid,ids,context=context):
			for invoices in orden.facturas3:
				self.pool.get('account.invoice').write(cr,uid,invoices.id,{'state':"solicitud_pago"},context=context)
			self.write(cr,uid,ids,{'fecha_aprobacion':datetime.today()-relativedelta(hours=6)})
			secuencia=self.pool.get('ir.sequence').get(cr, uid, 'secuencia_orden_pago')
			self.write(cr,uid,ids,{'name':secuencia})
			self.write(cr,uid,ids,{'state':"open"})

	def confirmar_pago(self,cr,uid,ids,context=None):
		for orden in self.browse(cr,uid,ids,context=context):
			for invoices in orden.facturas3:
				self.pool.get('account.invoice').write(cr,uid,invoices.id,{'state':"validacion_pago"},context=context)
			self.write(cr,uid,ids,{'fecha_confirmacion':datetime.today()-relativedelta(hours=6)})
			self.write(cr,uid,ids,{'state':"done"})


	def obt_group(self,cr,uid,ids,fields,args,context=None):
		res={}
		obj_grupo_ids=self.pool.get('res.groups').search(cr,uid,[('name','=','Ordenes de pago')],context=context)
		obj_group=self.pool.get('res.groups').browse(cr,uid,obj_grupo_ids,context=context)
		for orden in self.browse(cr,uid,ids,context=context):
			for usuario in obj_group.users:
				if uid == usuario.id:
					res[orden.id] = True
					break
					
				else:
					res[orden.id] = False
		return res

	def _getTotals(self, cr, uid, ids, field, arg, context=None):
		result = 0.0
		for orden in self.browse(cr,uid,ids,context=context):
			for invoices in orden.facturas3:
				result += invoices.residual
		return result

	  
	_name = 'orden_pagos'
	_columns = {
	   'is_group_manager':fields.function(obt_group,string="grupo",type="boolean"),
	   'fecha_aprobacion':fields.date('Fecha de Aprobacion',help="Fecha de aprobacion"),
	   'fecha_confirmacion':fields.date('Fecha de Confirmacion',help="Fecha de Confirmacion"),
	   'name':fields.char(string="Referencia",help="Referencia de la orden"),
	   'responsable':fields.many2one('res.users',string="Responsable",help="Responsable de la creacion de ordenes de pago" default=lambda self: self.env.user),
	   'facturas3':fields.one2many('account.invoice','orden_id',string="ordenes"),
	   'mchecks':fields.one2many('mcheck.mcheck','order_id',string="mcheck"),
	   'total': fields.function(_getTotals, type='float', string='Saldo'),
	   'state': fields.selection([
		    ('draft', 'Borrador'),
		    ('cancel', 'Cancelado'),
		    ('open', 'Confirmado'),
		    ('done', 'Finalizado')], 'Status', select=True, copy=False,
            help='Cuando la orden es creada esta en estado \'Borrador\'.\n una vez confirmado el estado cambia a \'Confirmado\'.\n Luego la orden es validada y pasa al estado \'Finalizado\'.'),

}

	_defaults={
		'state': 'draft',
		'responsable': lambda self,cr,uid,context: uid,

	
		}








