# -*- coding: utf-8 -*-

import time
from openerp.osv import fields, osv
from openerp.tools.translate import _

class anullation_date_wizard(osv.osv_memory):
	_name = 'template_docid_select'
	
	def Select_Doc(self, cr, uid, ids, context = None):
		valores={}	
		if context.get('active_id'):
			for selected_doc in self.browse(cr,uid,ids, context = context):
				if selected_doc.to_mcheck and selected_doc.doc_id_mcheck:
					valores={'doc_id': selected_doc.doc_id_mcheck,'doc_type' :selected_doc.doc_id_mcheck.doc_type }
				elif selected_doc.to_debit_credit and selected_doc.doc_id_debit_credit:
					valores={'doc_id': selected_doc.doc_id_debit_credit,'doc_type' : selected_doc.doc_id_debit_credit.doc_type }
				else:
					raise osv.except_osv(_('Configuration Error !'),_("Try again Please"))
			self.pool.get('banks.template').write(cr, uid, context.get('active_id'),valores, context=context)
		else:
			raise osv.except_osv(_('Error!'),_("The operation was not finished, Try Again!"))
	'''def onchange_type_doc(self, cr, uid, ids,mcheck_selected,dc_selected, context = None):
		if mcheck_selected: 
			return { 'value' :{ 'to_mcheck' : False,'to_debit_credit' : True }}
		else:
			return { 'value' :{}}'''
	_columns = {

	'to_mcheck': fields.boolean('Mcheck or Transferences',  select=True, 
                           help=_("Use as Mchecks and Transferences Template"),required=False ),
	'to_debit_credit': fields.boolean('Debit or Dredit',  select=True, 
                           help=_("Use as Debit or credit Template"),required=False),
	'doc_id_mcheck': fields.many2one('mcheck.mcheck','Document',  select=True, 
                           help=_("Document to use as template"),required=False ),
	'doc_id_debit_credit': fields.many2one('debit.credit','Document',  select=True, 
                           help=_("Document to use as template"),required=False ),
	}
