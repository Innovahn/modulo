# -*- coding: utf-8 -*-

import time
from openerp.osv import fields, osv
from openerp.tools.translate import _
from openerp import api
from openerp.exceptions import except_orm, Warning, RedirectWarning
from openerp.tools import float_compare
from datetime import datetime,timedelta
from itertools import ifilter
class manual_conciliation(osv.osv_memory):
	_name = 'manual.move.conciliation.asssign'
	
	def search_move(self, cr, uid, ids, context = None):
		context = dict(context or {})
		'''
		#criterios = 
		amlines = []
		#if context.get('',False) and 
		aml_pool = self.pool.get('account.move.line')
		amline = aml_pool.search(cr, uid, criterios , context = context)'''
	def return_to_concil(self, cr, uid, ids, context = None):
		context = dict(context or {})
		concil_pool = self.pool.get('banks.conciliation.lines')
		line = False
		for actual in self.browse(cr, uid, ids , context = context):
			if actual.conciliation_id:
				if not (len(actual.move_lines) != 1):
					for lineas in actual.move_lines:
						line = lineas.id
				else:
					raise osv.except_osv(_('Error'),_("You have to select just one document to link"))
				concil_pool.write(cr, uid, actual.conciliation_id.id,{ 'doc_reference' : line ,'concil_method' : 'manual'}, context = context)
			else:
				raise osv.except_osv(_('Error'),_("The document could not be linked to this movement, close this windows and try again!"))
		
	_columns = {
		'conciliation_id' : fields.many2one('banks.conciliation.lines', String='Reference', copy=False),
		'date':fields.date('Date',  select=True, ),
		'reference': fields.char(string='Bank Reference'),
		'type': fields.char(string='Type'),
		'debit': fields.float(string='Debit'),
		'credit': fields.float(string='Credit'),
		#'search_criteria': fields.char(string='Search'),
		'field_search_1':fields.boolean('Reference'),
		'field_search_data_1':fields.char('->'),
		'field_search_2':fields.boolean('Date'),
		'field_search_data_2':fields.date('->',  select=True,),
		'field_search_3':fields.boolean('Journal'),
		'field_search_data_3': fields.many2one('account.journal', '->', copy=False),
		'field_search_4':fields.boolean('Amount'),
		'field_search_data_4':fields.float('->'),
		'move_lines': fields.many2many('account.move.line',),
	}

	_defaults = {
		'date' : lambda self, cr, uid, context: context['date'] if context and  context['date'] not in [False,None] else  False,
		'type' : lambda self, cr, uid, context: context['type'] if context and  context['type'] not in [False,None] else  False,
		'reference' : lambda self, cr, uid, context: context['reference'] if context and  context['reference'] not in [False,None] else  False,
		'debit' : lambda self, cr, uid, context: context['debit'] if context and  context['debit'] not in [False,None] else  False,
		'credit' : lambda self, cr, uid, context: context['credit'] if context and  context['credit'] not in [False,None] else  False,
		'conciliation_id' : lambda self, cr, uid, context: context['conciliation_id'] if context and  context['conciliation_id'] not in [False,None] else  False,
		 } 
