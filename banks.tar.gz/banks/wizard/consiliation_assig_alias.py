# -*- coding: utf-8 -*-

import base64
import time

from openerp.osv import fields, osv
from openerp.tools.translate import _
from openerp import tools

import logging

_logger = logging.getLogger(__name__)

class account_coda_import(osv.osv_memory):
        _name = 'banks.consiliation.coda.import'
        _description = 'Import CODA File'
        _columns = {
            'coda_data': fields.binary('Bank File', required=True),
            'coda_fname': fields.char('Bank Filename', required=True),
            'note': fields.text('Log'),
        }

        _defaults = {
            'coda_fname': 'coda.txt',
        }

	def es_debit_or_credit(self,cr, uid, ids, reference, conciliation_id,  context = None):
		if reference:
			conc_pool = self.pool.get('banks.conciliation')
			conc_obj = conc_pool.browse(cr, uid, conciliation_id,context=context)
			for co in conc_obj:
				for db in conc_obj.config_ref.debits:
					if reference == db.name:
						return 'db'
				for cr in conc_obj.config_ref.credits:
					if reference == cr.name:
						return 'cr'
		return False

	def update_docs_references(self,cr, uid, ids,  move_line_id, concil_id, context = None):
		aml_pool = self.pool.get('account.move.line')
		bcl_pool = self.pool.get('banks.conciliation.lines')
		aml_pool.write(cr, uid, move_line_id ,{'conciliation_ref' : concil_id}, context = context)
		bcl_pool.write(cr, uid, concil_id,{'doc_reference' : move_line_id , 'concil_method' : 'automatic'}, context = context)

	def buscar_mejor_coincidencia(self,cr, uid, ids, posibles_resultados,id_conciliation, context = None):
		for resultado in posibles_resultados:
			print ""
	def buscar_registro_conciliador(self, cr, uid, ids, cline, id_conciliation, context = None):
		aml_pool = self.pool.get('account.move.line')
		amove_pool = self.pool.get('account.move')
		actual_dic = {}
		actual_dic = dict(cline or {})
		filtro = []
		filtro_move = []
		id_resultante = None
		if actual_dic.get('debit',0) > 0:
			filtro.append(('credit', '=' ,float(str(actual_dic.get('debit')))))
		elif actual_dic.get('credit',0) > 0:
			filtro.append(('debit', '=' ,float(str(actual_dic.get('credit')))))
		filtro_move.append(('date', '=' ,str(actual_dic.get('date'))))
		amove_obj = amove_pool.browse(cr, uid, amove_pool.search(cr, uid, filtro_move ,context = context),context = context)
		posibles_resultados = []
		ids_resultante = []
		for move_line in amove_obj:
			filtr = []
			filtr = filtro
			filtr.append(('move_id','=',move_line.id))
			filtr.append(('conciliation_ref','in',[False,None]))
			ids_resultante =  aml_pool.search(cr, uid,filtr ,context=context)
		if len(ids_resultante) == 1:
			self.update_docs_references( cr, uid, ids, ids_resultante[0], id_conciliation,  context = context)
		elif len(ids_resultante) > 1:
			self.buscar_mejor_coincidencia( cr, uid, ids, ids_resultante,id_conciliation, context = context)
		else:
			return False	

												
	def create_conciliation_dato(self, cr, uid, ids, data,id_conciliation,  context = None):
		if data:
			con_pool = self.pool.get('banks.conciliation.lines')
			for linea in data:
				cline = {}
				line = {}
				line = dict(linea or {})
				cline['conciliation_id'] = id_conciliation
				cline['date'] = line.get('date',False)
				cline['type'] = line.get('type',False)
				cline['reference'] = line.get('reference',False)
				if line.get('amount',False) in [None,False,0]:
					cline['debit'] = line.get('credit',False)
					cline['credit'] = line.get('debit',False)
				else:
					print line.get('type',False)
					resul = self.es_debit_or_credit(cr, uid, ids, str(line.get('type',False)).strip(), id_conciliation,  context = context)
					if resul == 'db':
						cline['credit'] = line.get('amount')
					elif resul == 'cr':
						cline['debit'] = line.get('amount')
				b = con_pool.create(cr, uid, cline,context = context )
				if b:
					self.buscar_registro_conciliador(cr, uid, ids, cline , b, context = context)

	def convert_line(self,cr, uid, ids, lineas, context = None):
		context = dict(context or {})
		result = {}			
		bank_concil = self.pool.get('banks.conciliation')
		bank_concil_obj = bank_concil.browse(cr, uid, context.get('conciliation_ref',False), context=context)
		if not bank_concil_obj:
			raise osv.except_osv(_('Error'), _('Sorry, there was a problem loading configuration data'))
		if bank_concil_obj.config_ref.sep_character in [False,None]:
			raise osv.except_osv(_('Error'), _('Configure a separation caracter like , or blank spaces'))
		result.update({'date':None,'refernece':None,'type':None,'debit':None,'credit':None,'amount':None})
		arreglo_lineas = []
		for l in lineas:
			arreglo_lineas.append(l.split(bank_concil_obj.config_ref.sep_character))
		result_lineas = []
		for line in arreglo_lineas:
			if len(line) > 0:
				result = {}
				result = dict(result or {})
				if not bank_concil_obj.config_ref.amount > 0:
					result.update({'credit' : line[bank_concil_obj.config_ref.credit-1]})
					result.update({'debit' : line[bank_concil_obj.config_ref.debit-1]})
				else:
					result.update({'amount' : line[bank_concil_obj.config_ref.amount-1]})
				result.update({'date' : line[bank_concil_obj.config_ref.date-1]})
				result.update({'reference' : line[bank_concil_obj.config_ref.reference-1]})
				result.update({'type' : line[bank_concil_obj.config_ref.type-1]})
				result_lineas.append(result)
		return result_lineas

	def coda_parsing(self, cr, uid, ids, context=None, batch=False, codafile=None, codafilename=None):
		if context is None:
            		context = {}
		context = dict(context or {})
		if batch:
		        codafile = str(codafile)
		        codafilename = codafilename
		else:
		    data = self.browse(cr, uid, ids)[0]
		    try:
		        codafile = data.coda_data
		        codafilename = data.coda_fname
		    except:
		        raise osv.except_osv(_('Error'), _('Wizard in incorrect state. Please hit the Cancel button'))
		        return {}
		recordlist = unicode(base64.decodestring(codafile), 'windows-1252', 'strict').split('\n')
		statements = []
		globalisation_comm = {}
		i=5#deberia ser la linea donde comienzan los movimientos, dinamicamente
		lineas =[]
		#for i in range(5,10):
		#	i+=1
		#	lineas.append(recordlist[i])
		#print lineas
		bandera = False
		for li in recordlist:
			if bandera:
				lineas.append(li)
			else:
				bandera = True
		
		lineas.pop(-1)		
		line_converts = self.convert_line(cr,  uid, ids,lineas,context)
		self.create_conciliation_dato(cr, uid, ids, line_converts, context.get('conciliation_ref',False) ,  context = context)




