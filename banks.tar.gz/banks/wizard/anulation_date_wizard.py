# -*- coding: utf-8 -*-

import time
from openerp.osv import fields, osv
from openerp.tools.translate import _

class anullation_date_wizard(osv.osv_memory):
	_name = 'anullation_date_wizard'
	
	def Anulate_doc(self, cr, uid, ids, context = None):	
		if context.get('active_id'):
			self.pool.get('mcheck.mcheck').cancel_voucher(cr, uid, context.get('active_id'),self.browse(cr,uid,ids, context = context).date, context=context)
		else:
			raise osv.except_osv(_('Error!'),_("The operation was not finished, Try Again!"))
	_columns = {

	'date':fields.date('Date',  select=True, 
                           help=_("Effective date for  anullation"),required=True ),
	}
