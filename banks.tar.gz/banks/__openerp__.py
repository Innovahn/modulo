# -*- coding: utf-8 -*-
{	
	'name' : 'Banks',
	'author': 'Grupo Innova',
	'category': 'Generic Modules/Accounting',
	'summary': 'This module allows you to manage all about banking',
	'description': """Banks, 
				This module allows you to manage miscellaneous checks, debits, credits, deposits, 
				checkbooks, banks. 
				Miscellaneous checks:  -You can manage all of miscellaneous checks -If
				you want to make a retention in these checks, you have to use an account that is used for retentions
				Debits and Credist: -You can manage debits and credit, and also create temnplates of and existent document to use it in the future
				Deposits : -You can manage deposits.
				each of these documents have the option to cancel journal entries
				Checkbooks: With this option you can vinculate a journal to a bank and an expecific bank account
				Templates: Use to allow you use documents as templates for the creation of future documents""",

	'data':[
		
		'reports/write_cheqck_paper_format.xml',
		'reports/cheqck_paper_format.xml',
		'wizard/anulation_date_wizard.xml',
		'wizard/template_docid_select.xml',	
		'views/account_voucher.xml',
		'views/account_account_view.xml',
		'views/costumer_payment_view.xml',
		'views/config_journal_view.xml',
		'views/credit_debit_view.xml',
		'views/write_checks_view.xml',
		'views/layouts.xml',
		'views/mcheck_reports.xml',
		'views/mcheck_view.xml' ,
		'views/deposit.xml',
		'views/write_checks_report.xml',
		'views/banks_transferences.xml',
		'views/banks_checkbooks.xml',
		'views/banks_banks_view.xml',
		'views/banks_templates.xml',
		'views/account_voucher_amount_word.xml',
		'views/banks_consiliation.xml',
		'reports/reporte1.xml',
		'reports/reporte2.xml',
		'data/sequence_codes.xml',
		'data/mail_tread_messages.xml',
		'reports/checkbooks_general_Ledger.xml',
		'wizard/consiliation_assig_alias.xml',
		'wizard/consiliation_manual_assign.xml',
	],
	'update_xml' : [
			'security/groups.xml',
			'security/ir.model.access.csv'
	],
	'depends': ['base','innova_account_plus','account_check_writing'],
    	'installable': True,
}
