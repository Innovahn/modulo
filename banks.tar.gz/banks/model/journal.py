# -*- coding: utf-8 -*-

from openerp.osv import fields, osv
from openerp import models, api
from datetime import datetime
import locale
import pytz
from openerp.tools.translate import _

class banks_account_journal(osv.osv):



	#asociate to the default journal sequence, the secuence for checks thaht is defined in the journal sequences 
	#this function will run when multisequence is defined
	def onchange_multy_currency(self, cr, uid,ids, allow_multi_sequence, context=None):
		if allow_multi_sequence:
			for journal in self.browse(cr,uid,ids,context=None):
				if journal.sequence_ids:
					for seqs in journal.sequence_ids:
						if seqs.code=='check' :
							self.write(cr,uid,ids,{'sequence_id':seqs.id},context=context)
							return { 'value' : {'sequence_id' : seqs.id} }
				else:
					return False
			return False						
		else:	
			return False
	
	def existe_repeat(self, cr, uid, ids,sequence_ids_list,  context=None):
		if sequence_ids_list:
			cont=0
			ir_seq_pool = self.pool.get('ir.sequence')
			sequence_ids = ir_seq_pool.browse(cr, uid, sequence_ids_list[0][2],context=context)
			for seqs in sequence_ids:
				for seqs2 in sequence_ids:
					if seqs.code not in [None,False] and seqs2.code not in [None,False]:
						if not (seqs == seqs2):
							if seqs.code == seqs2.code:
								cont+=1
								if cont>0:
									cont=0
									return seqs.code
				cont=0
			return False
		else:
			return False
						
	def write(self, cr, uid, ids, vals, context=None):
		vals = dict(vals or {})
		bandera=True
		ir_seq_pool = self.pool.get('ir.sequence')
		journal = self.browse(cr,uid,ids,context=context)
		if journal.sequence_id.id:
			vals['sequence_id'] = journal.sequence_id.id
		else:
			vals['sequence_id'] = None
		if vals.get('sequence_ids',False) not in [None,False]:
			sequence_ids = ir_seq_pool.browse(cr, uid, vals['sequence_ids'][0][2],context=context)
			if sequence_ids:
				for seqs in sequence_ids:
					if seqs.code=='check' :
						vals['sequence_id'] = seqs.id
						bandera = False
				if bandera:
					sequence_ids_obj = ir_seq_pool.browse(cr, uid, ir_seq_pool.search(cr, uid,[],context=context), context=context)
					for seq in sequence_ids_obj:
						if journal.name == seq.name:
							vals['sequence_id'] = seq.id
				res = self.existe_repeat(cr, uid, ids,vals['sequence_ids'],  context=context)
				if not res:
					return super(banks_account_journal, self).write(cr, uid, ids, vals, context=context)
				else:
					raise osv.except_osv(_('Error!'),_("There is more than one sequence with the code '"+res+"', you have to delete or change one") )	
		else:
			return super(banks_account_journal, self).write(cr, uid, ids, vals, context=context)



	def create(self, cr, uid, values,  context=None):
		values = dict(values or {})
		if values.get('sequence_ids'):
			b = super(banks_account_journal, self).create(cr, uid, values, context=context)
			if b:
				res=self.existe_repeat(cr, uid, b, values['sequence_ids'],context=context)
				if not res:
					journal = self.browse(cr,uid,b,context=context)
					if journal.sequence_ids:
						for seqs in journal.sequence_ids:
							if seqs.code=='check' :
								self.write(cr, uid, b, { 'sequence_id' : seqs.id }, context=context)
					return b
				else:
					raise osv.except_osv(_('Error!'),_("There is more than one sequence with the code '"+res+"', you have to delete or change one") )

			else:
				return False
		else:
			return False
	def copy(self, cr, uid, id, default=None, context=None):
		default = dict(context or {})
		journal = self.browse(cr, uid, id, context=context)
		default.update(
			code=_("%s (copy)") % (journal['code'] ),  
		        name=_("%s (copy)") % (journal['name'] )),
		        #allow_multi_sequence=False
		default['allow_multi_sequence']=False
		default['checkmiscelaneous']=False
		default['allow_check_writing']=False
		default['allow_banks_transferences']=False
		default['allow_multi_sequence']=False
		return super(account_journal, self).copy(cr, uid, id, default, context=context)
	_inherit = 'account.journal'
	_columns = {
		'checkmiscelaneous' : fields.boolean(string="Miscellaneous Checks"),
		'allow_creditdebit' : fields.boolean(string="Allow debit and credit"),
		'allow_multi_sequence' : fields.boolean(string="Allow Multi-Sequence"),
		'allow_banks_transferences' : fields.boolean(string="Allow Banks Tramsactions"),
		'sequence_ids' : fields.many2many('ir.sequence',string='Sequences'),
		'commission_account' : fields.many2one('account.account',string='Commission account'),	
	}
	_defaults = {
	'checkmiscelaneous' : False,
	'allow_creditdebit' : False,
	'allow_multi_sequence' : False,
	'allow_banks_transferences' : False,
		} 
