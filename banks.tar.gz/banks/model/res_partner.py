# -*- coding: utf-8 -*-
##used to give res_partner_acces rights
from openerp import models, api
from openerp.osv import fields, osv

class res_partner(osv.Model):
	_inherit = 'res.partner'
