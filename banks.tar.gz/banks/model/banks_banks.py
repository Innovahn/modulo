# -*- coding: utf-8 -*-

from openerp.osv import fields, osv
from datetime import datetime
import locale
import pytz
from openerp.tools.translate import _

class banks_banks(osv.osv):
	_name = 'banks.banks'
	_columns = {
		'name' : fields.char( 'Bank', 
		                         help="Transaction reference number.", copy=False,required=True )
	}
	 
