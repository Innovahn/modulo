# -*- coding: utf-8 -*-

from openerp import models, api
from openerp.osv import fields, osv
from datetime import datetime
import openerp.addons.decimal_precision as dp
import locale
import pytz
from openerp.tools.translate import _
import time
from itertools import ifilter
class banks_transferences(osv.Model):
	_name ='banks.banks.transferences'
	_description='banks.banks.transferences'
	_inherit = ['mail.thread']
	_track = {
        'state': {
            'banks_transferences.banks_transferences_total_change': lambda self, cr, uid, obj, context=None: True,
       		 },
   	 }
	
	#function that brings currency rates from a particular
	def calculate_curr_rates(self,cr, uid, ids,context=None):
		company_currency = None
		journal_currency = None
		model_user = self.pool.get('res.users')
		obj_user = model_user.browse(cr,uid,model_user.search(cr,uid,[('id' , '=', uid )],context=None),context=context)
		model_company = self.pool.get('res.company')
		obj_company = model_company.browse(cr,uid,model_company.search(cr,uid,[('id' , '=', obj_user.company_id.id )],context=None),context=context)
		for bt in self.browse(cr,uid,ids,context=context):
			company_currency = obj_company.currency_id.with_context(date=bt.date)
			if bt.orig_journal_id.currency:
				journal_currency = bt.orig_journal_id.currency.with_context(date=bt.date)
				if company_currency and journal_currency: 
					return {'company_curr_id' : company_currency.id , 'company_curr_rate' : company_currency.rate ,'journal_curr_id': journal_currency.id, 'journal_curr_rate': journal_currency.rate}
				else:
					raise osv.except_osv(_('Error!'),_("Operation was not finished, Try Again") )
			else:
				if company_currency:
					return {'company_curr_id' : company_currency.id , 'company_curr_rate' : company_currency.rate ,'journal_curr_id': None, 'journal_curr_rate': None}
				else:
					raise osv.except_osv(_('Error!'),_("Operation was not finished, Try Again") )



	def _get_sequence(self, cr, uid,  ids, journalid,doc_type, context=None):
		journal_obj = self.pool.get('account.journal')
		diario = journal_obj.browse(cr,uid,journal_obj.search(cr,uid,[('id','=',journalid)],context=None),context=context)
		seq_id = None
		have_multi=False
		seq_id = diario.sequence_id.id
		for sq in diario.sequence_ids:
			have_multi = True
			if sq.code == doc_type:
				seq_id = sq.id
		return {'result' : have_multi, 'seq_id' : seq_id}

	def update_sequence(self,cr, uid, ids, journal_id, doc_type, context=None):
		journa_obj = self.pool.get('account.journal')
		diario = journa_obj.browse(cr,uid,journa_obj.search(cr,uid,[('id','=',journal_id)],context=None),context=context)
		seq_id=0
		fl=False
		for d in diario.sequence_ids:
			if d.code=='banks_transferences':
				seq_id=d.id
				fl=True
		if fl:
			cr.execute("UPDATE ir_sequence SET number_next=number_next+number_increment WHERE id=%s ", (seq_id,))
			return True
		else:						
			raise osv.except_osv(_('Error !'),_("Could't update the sequence for this journal!"))

	def journal_number(self,cr,uid,ids,journalid,doc_type,context=None):
		if not journalid==False and doc_type !=False:
			context = dict(context or {})
			force_company = self.pool.get('res.users').browse(cr, uid, uid).company_id.id#id of the company of the user
			seq_model = self.pool.get('ir.sequence')
			name = "/"
			journal_obj = self.pool.get('account.journal')
			diario = journal_obj.browse(cr,uid,journal_obj.search(cr,uid,[('id','=',journalid)],context=None),context=context)
			seq_id=0
			fl=False
			for sq in diario.sequence_ids:
				if sq.code == doc_type:
					seq_id = sq.id
					fl = True
			if not fl:
				return None
		
			if diario.sequence_id:
				if not diario.sequence_id.active:
					raise osv.except_osv(_('Configuration Error !'),_('Please activate the sequence of selected journal !'))
				context.update({'no_update' : True})
				name = seq_model.next_by_id(cr, uid, int(seq_id),context=context)
				return  name
			else:
				return None
		else:
			return None


	def unlink(self, cr, uid, ids, context=None):
		bts = self.pool.get('banks.banks.transferences').browse(cr,uid,ids,context=context)
		flag = False
		for bt in bts:
			if bt.state not in  ['draft'] or bt.was_unreconcilied:
				flag= True
		if flag:
			raise osv.except_osv(_('Error!'),_("You can not delete a bank transference when it has a diferent state than Draft or it has been unreconcilied!"))
		else:
			return super(banks_transferences, self).unlink(cr, uid, ids, context=context)

	def create(self, cr, uid, values, context=None):
		if values['number'] is not None and  values['number'] is not False:
			b =super(banks_transferences, self).create(cr, uid, values, context=context)
			if b:
				return b
			else:	
				return False	
		else:
			raise osv.except_osv(_('Configuration Error !'),_("Please Create a sequence code with the code '"+str(values['doc_type'])+"' or add a sequence for this journal with the code '"+str(values['doc_type'])+"'"))	


	def action_validate(self, cr, uid, ids, context=None):
		for  bt in self.browse(cr,uid,ids,context=context):
			if  ((bt.orig_journal_id.id != bt.dest_journal_id.id) and (bt.orig_journal_id.type == 'bank' and bt.dest_journal_id.type == 'bank') and (bt.orig_journal_id.currency.id == bt.dest_journal_id.currency.id )):
				currency_rate = 0.0
				model_currency_rate = None
				decimal_precision = self.pool.get('decimal.precision')
				dec_prec = decimal_precision.browse(cr,uid,decimal_precision.search(cr,uid,[('name' , '=', 'Account' )],context=None),context=context)
				for m in self.browse(cr,uid,ids,context=context):
					model_user = self.pool.get('res.users')
					obj_user = model_user.browse(cr,uid,model_user.search(cr,uid,[('id' , '=', uid )],context=None),context=context)
					model_company = self.pool.get('res.company')
					obj_company = model_company.browse(cr,uid,model_company.search(cr,uid,[('id' , '=', obj_user.company_id.id )],context=None),context=context)
			
			
				curr_rates={}
				curr_rates = self.calculate_curr_rates(cr, uid, ids, context=context)
				currency_rate = curr_rates['company_curr_rate']
				currency_id = curr_rates['company_curr_id']
				#id of the currency for tha company thah im linked with
				select_journal_currency_id = bt.orig_journal_id.currency.id#the currency of the journal selected, if it dosent have it, it will see if the default account have a currency, in defect it will be the default company currency
				if select_journal_currency_id:#if there is a secundary currency, brings the curency rate for this currency
					select_journal_currency_rate = curr_rates['journal_curr_rate']				
					#select_journal_currency_name = curr_rates['journal_curr_rate']
								
				else: 				
					select_journal_currency_rate = currency_rate 
					select_journal_currency_id = currency_id

				
				#brings the object with the corresponding period for the date escogida
				account_period = self.pool.get('account.period')
				account_period_obj = account_period.browse(cr,uid,account_period.search(cr,uid,['&','&',( 'date_start','<=', bt.date ),('date_stop', '>=',bt.date),('special','<>',True),('company_id','=',bt.orig_journal_id.company_id.id),('state', '=', 'draft')],context=None),context=context)
				if not account_period_obj:
					raise osv.except_osv(_('Error!'),_("There is not an open period for you company on the selected date"))
				totalc_curr = 0
				totald_curr = 0
				totald=0
				totalc=0
				lines_array=[]
				name = "/"
				if bt.number:
					name=bt.number
				amove_obj= self.pool.get('account.move')
				amovedata={}
				amovedata['journal_id']=bt.orig_journal_id.id
				amovedata['name']=name
				amovedata['date']=bt.date
				amovedata['period_id']=account_period_obj.id
				amovedata['ref']=bt.name
				move_id= amove_obj.create(cr,uid,amovedata)
				mline_obj= self.pool.get('account.move.line')
				for m in [1,2]:
					lines_col={}
					lines_col['move_id'] = move_id
					lines_col['bank_transferences_id']=bt.id
					lines_col['mod_origen'] = 4#type 1 is banks transferences
					if m==1:
						lines_col['name']= bt.dest_journal_desc or '/'
						lines_col['account_id']=bt.dest_journal_id.default_debit_account_id.id
						lines_col['credit']=0
						if (select_journal_currency_rate !=0):
							lines_col['debit'] = round((bt.total * (1/select_journal_currency_rate))*currency_rate,dec_prec.digits)
						else:
							lines_col['debit'] = round(bt.total * currency_rate,dec_prec.digits)
						totald+=lines_col['debit']
						if select_journal_currency_id == currency_id:#si el currency de 
							totald_curr+=lines_col['debit']
						else:
							lines_col['amount_currency']=(bt.total * (1/select_journal_currency_rate))*select_journal_currency_rate#shame on me, hahahaha 1(x/y)y=x
							lines_col['currency_id'] = select_journal_currency_id
							totald_curr+=bt.total		
					else:
						lines_col['name']=bt.orig_journal_desc  or '/'
						lines_col['account_id']=bt.orig_journal_id.default_credit_account_id.id
						lines_col['debit']=0
						lines_col['credit'] = round(((bt.total * (1/select_journal_currency_rate))*currency_rate),dec_prec.digits)
						totalc+=lines_col['credit']  #total of debit multiplicated by default
						if select_journal_currency_id == currency_id:
							totalc_curr+=lines_col['credit']
						else:
							lines_col['amount_currency'] = (bt.total * (1/select_journal_currency_rate))*(-1)*select_journal_currency_rate
							lines_col['currency_id'] = select_journal_currency_id
							totalc_curr+=bt.total
					lines_array.append(lines_col)
				for lines2 in lines_array:
					mline_obj.create(cr,uid,lines2)
				seq_id=0
				fl=False
				if not bt.was_unreconcilied:
					n=self.journal_number(cr,uid,bt.id,bt.orig_journal_id.id,'banks_transferences',context=None)
				else:
					n=bt.number
				self.update_sequence(cr, uid, bt.id ,bt.orig_journal_id.id,'banks_transferences', context=None)
				self.update_state_draf(cr, uid, bt.id,bt.orig_journal_id.id,'banks_transferences', context=None)#actualiza el estado de los cheques o transacciones que esten en draft
				jour_comp_id = None
				if  bt.orig_journal_id.company_id.id:
					jour_comp_id = bt.orig_journal_id.company_id.id
				else:
					jour_comp_id= self.pool.get('res.user').browse(cr,uid,uid, context=context).company_id.id
				return self.write(cr, uid, ids, {'state':'validated','number':n,'move_id':move_id, 'actual_comp_rate': currency_rate,'actual_sec_curr_rate': select_journal_currency_rate , 'jour_company_id' : jour_comp_id}, context=context)
			else:
				raise osv.except_osv(_('Error!'),_("Configuration error") )

	def update_state_draf(self, cr, uid, ids,journal_id,doc_type, context=None):
		seq = self._get_sequence(cr, uid, ids, journal_id,doc_type, context=None)
		if seq['seq_id'] != None:
			bankstran_model = self.pool.get('banks.banks.transferences')
			bankstran_obj=bankstran_model.browse(cr,uid,bankstran_model.search(cr,uid,[('state','=','draft' ),('orig_journal_id','=',journal_id), ('was_unreconcilied','!=',True )],context=None),context=context)
			nn=self.journal_number(cr,uid,ids,journal_id, doc_type,context=None)
			for draft_bank_tran in bankstran_obj:
				bankstran_model.write(cr, uid, draft_bank_tran.id, {'number':nn}, context=context)
	
	def onchange_journal(self,cr, uid, ids, journal_id, context=None):
		if journal_id is False:
			msj="Selec a Type and a Journal"
		else:
			msj="Warnig! Please Create a sequence code with the code 'banks_transferences' or add a sequence for the Origin  journal with the code 'banks_transferences'"
		n=self.journal_number(cr,uid,ids,journal_id, 'banks_transferences' ,context=None)
		if n is None or n is False:
			return { 'value' :{ 'number' : n,'number_calc' : n,'msg' : msj}}
		else:
			return { 'value' :{ 'number' : n,'number_calc' : n,'msg' : None}}


	def _calculate_number(self,cr, uid, ids, field, arg, context=None):
		result={}
		for bt in self.browse(cr,uid,ids,context=context):
			result[bt.id]=bt.number
		return result
	
	def _get_msg(self,cr, uid, ids, field, arg, context=None):
		result={}
		for mcheck in self.browse(cr,uid,ids,context=context):
			result[mcheck.id]=None
		return result

	def unreconciliate_bnk_transfers(self, cr, uid, ids, context=None):
		reconcile_pool = self.pool.get('account.move.reconcile')
		move_pool = self.pool.get('account.move')
		move_line_pool = self.pool.get('account.move.line')
		journal_id = False
		for bt in self.browse(cr, uid, ids, context=context):
			# refresh to make sure you don't unlink an already removed move
			bt.refresh()
			journal_id = bt.orig_journal_id.id
			if bt.move_id:
				move_pool.button_cancel(cr, uid, [bt.move_id.id])
				move_pool.unlink(cr, uid, [bt.move_id.id])
		res = {
		    'state':'draft',
		    'move_id':False,
		    'was_unreconcilied' : True,
		}
		self.write(cr, uid, ids, res)
		self.update_state_draf(cr, uid, ids ,journal_id,'banks_transferences', context=None)#actualiza el estado de los cheques o transacciones que esten en draft
		return True
	_columns = {
		'move_id':fields.many2one('account.move', 'Account Move', copy=False),
		'move_ids' :fields.one2many('account.move.line','bank_transferences_id',string="Transferences Account Move lines"),
		'orig_journal_id':fields.many2one('account.journal', 'Origin Journal',required=True ),
		'orig_journal_desc':fields.char('Origin Journal Description',required=True ),
		'dest_journal_id':fields.many2one('account.journal', 'Destiny Journal',required=True ),
		'dest_journal_desc':fields.char('Destiny Journal Description',required=True ),
		'total': fields.float(string='Total',required=True, track_visibility='onchange',),
		'was_unreconcilied': fields.boolean(string='Unreconcilied'),	
		'name':fields.text('Memo', required=True),	
		'date':fields.date('Date',  select=True, 
                           help="Effective date for accounting entries", ),
		'number': fields.char('Number'),
		'jour_company_id' : fields.integer(string='Company',),
		'actual_comp_rate' : fields.float('Company rate'),
		'actual_sec_curr_rate' : fields.float('Actual Secundary Currency Rate'),
		'number_calc': fields.function(_calculate_number, type='char', string='Number', store=False),
		'msg': fields.function(_get_msg, type='char',  store=False),
		'obs':fields.text('obs',  ),
		'state':fields.selection(
		    [('draft','Draft'),
		     ('validated','Validated')
		    ], 'Status', track_visibility='onchange' ),
		}
	_order = 'number desc, date desc'
	_defaults = {
		'state' : 'draft',
		'date' :  lambda *a: time.strftime('%Y-%m-%d'),
}


	@api.multi
    	def copy(self, default=None):
		default = dict(default or {})

		default['number'] = self.journal_number(self.orig_journal_id.id, 'banks_transferences')
		default['state'] ='draft'
		default['date'] = datetime.now()
		default['orig_journal_id'] = self.orig_journal_id.id
		default['orig_journal_desc'] = self.orig_journal_desc
		default['dest_journal_id'] = self.dest_journal_id.id
		default['dest_journal_desc'] = self.dest_journal_desc
		default['total'] = self.total
		default['name'] = self.name
		
		encabezado = super(banks_transferences, self).copy(default)
		return encabezado



class account_move_line(osv.osv):
	_inherit = 'account.move.line'
	_columns = {
		'bank_transferences_id':fields.many2one('banks.banks.transferences','Banks Transferences'),
		}
