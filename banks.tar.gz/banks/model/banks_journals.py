# -*- coding: utf-8 -*-

from openerp.osv import fields, osv
from datetime import datetime
import locale
import pytz
from openerp.tools.translate import _

class banks_journals(osv.osv):
	_name = 'banks.checkbook'
	_columns = {
		'Bank' : fields.many2one( 'banks.banks' ),
		'bank_account' : fields.boolean(string="Allow debit and credit"),
		'Journal' : fields.many2one('account.journal'),	
	}
