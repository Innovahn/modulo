# -*- coding: utf-8 -*-

from openerp.osv import fields, osv
from datetime import datetime
import openerp.addons.decimal_precision as dp
import locale
import pytz
from openerp.tools.translate import _
import time
from itertools import ifilter
class account_consolidatio(osv.Model):
	_name = 'banks.mchecks.consolidations'

	
		
	
	_columns = {
			'number' : fields.char("Number"),
			'date' : fields.date('Date',  select=True, 
                           help="Effective date for accosunting entries"),
			'position' : fields.integer('pointer'),
			'type' :  fields.selection([
				('mcheck','Mcheck'),
				('voucher','Voucher'),
			],'Default Type', ),
			
	}
	
	
