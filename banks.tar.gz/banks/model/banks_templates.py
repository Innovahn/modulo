# -*- coding: utf-8 -*-
from openerp import models, api
from openerp.osv import fields, osv
import openerp.addons.decimal_precision as dp
from datetime import datetime
import locale
import pytz
from openerp.tools.translate import _
import time
from itertools import ifilter
class bank_template(osv.Model):

	_name = 'banks.template'

	def _get_user_id(self,cr,uid, ids, context=None):
		result={}
		result[ids]=uid
		return result
	_columns={
		'doc_type' : fields.selection([
						('check','Check'),
						('transference','Transference'),
						('deposit','Deposit'),
						('debit','Debit'),
						('credit','Credit'),
						('banks_transferencest','Banks Transferences')],string='Doc. type'),
	        'name':fields.char('Name', required=True),
		'doc_id' : fields.integer('Doc'),
		'journal_comp_id' : fields.integer('Journal company id'),
		
 	}
        
	def aceptar(self,cr, uid,ids, context=None):
		values={}
		values['doc_id']=context.get('doc_id')
		values['doc_type']=context.get('doc_type')
		self.create(cr, uid, values, context=context)

	def create(self,cr, uid,values, context=None):
		b =super(bank_template,self).create(cr, uid, values, context=context)
		if b:
			return b
		else:	
			return False
