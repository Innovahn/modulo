# -*- coding: utf-8 -*-
{    
    'name' : 'Campo Adicional',
    'author': 'Honduras Open Source',
    'category': 'Grupo Innova',
    'summary': 'Este modulo agrega un campo extra a los producto para la referencia anterior en Bazar Diana',
    'description': """Product Code""",
        'installable': True,
        'depends': ['product'],
        "data": [
        "views/product_code.xml"],
}
