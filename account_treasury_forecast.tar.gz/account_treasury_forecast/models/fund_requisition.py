# -*- encoding: utf-8 -*-

import openerp.addons.decimal_precision as dp
from openerp import models, fields, api, exceptions, _
from openerp.osv import  osv
class fund_requisition(models.Model):
	_name = 'funds.requisition'
	_description = 'Funds Requisition'

	date = fields.Date(string="Date")
	journal_id = fields.Many2one("account.journal", string="Journal")
	name = fields.Char(string="Name", required=False)
	reference = fields.Char(string="Reference", required=False)
	total = fields.Float(string="Amount", digits_compute=dp.get_precision('Account'))
	state = fields.Selection([('draft','Draft'),('done','Validated'),('anulated','Anulated'),], 'Status',)

	_defaults = {
		'state' : 'draft',
		    } 
	def action_validate(self, cr, uid, ids, context=None):
		self.write(cr, uid, ids,{'state' : 'done'}, context = context)

	def unlink(self, cr, uid, ids, context=None):
		for f in self.browse(cr, uid, ids,context = context):
			if f.state == 'done':
				raise osv.except_osv(_('Error!'),_("This document is in Validated state, you can't delete it") )
			else:
				super(fund_requisition,self).unlink(cr, uid, ids, context =  context)
