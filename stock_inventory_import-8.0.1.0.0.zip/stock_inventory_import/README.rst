Stock Inventory Import from CSV file
====================================

Wizard to import Inventory from a CSV file
The file must have at least 2 columns with "code" and "quantity" Head Keys.
You can also add a third column with Key "location" to add product location
(if not defined, default inventory location will be used)
You can also add a fourth column with Key "lot" to add a product lot.

Credits
=======

Contributors
------------
* Daniel Campos <danielcampos@avanzosc.es>
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Ana Juaristi <ajuaristio@gmail.com>
* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
