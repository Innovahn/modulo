# -*- encoding: utf-8 -*-
##############################################################################

{
    "name": "Flujo de Caja",
    "version": "1.0",
    "depends": [
        "account",
        "purchase",
	"banks",
	"financial",
	"odpagos",
    ],
    "author": "Editado por Honduras OpenSource",
    "website": "http://www.hondurasopensource.com",
    "category": "Accounting",
    "description": """
        This module manages the treasury forecast.
        Calculates the treasury forecast from supplier and customer invoices,
        recurring payments and variable payments.
    """,
    'data': [
        "security/ir.model.access.csv",
        "wizard/wiz_create_invoice_view.xml",
        "views/account_treasury_forecast_view.xml",
	"reports/report_cashflow.xml",
        "reports/report_cashflow_view.xml",
    ],
    'demo': [],
    'installable': True,
}
