# -*- encoding: utf-8 -*-

import openerp.addons.decimal_precision as dp
from openerp import models, fields, api, exceptions, _
from datetime import date,datetime
class PurchaseTreasuryForecast(models.Model):
    _name = 'account.treasury.forecast.purchase.order'
    _description = 'Treasury Forecast Purchase Order'
    partner_id = fields.Many2one("res.partner", string="Empresa")
    currency_id= fields.Many2one('res.currency', string='Currency')
    date_order = fields.Date(string="Fecha de Orden")
    purchase_id = fields.Many2one("purchase.order", string="Orden de Compra")
    state = fields.Selection([
        ('draft', 'Draft PO'),
        ('sent', 'RFQ'),
        ('bid', 'Bid Received'),
        ('confirmed', 'Waiting Approval'),
        ('approved', 'Purchase Confirmed'),
        ('except_picking', 'Shipping Exception'),
        ('except_invoice', 'Invoice Exception'),
        ('done', 'Done'),
        ('cancel', 'Cancelled')
    ])
    source_document=fields.Char(string="# Req. Compras")
    amount_total=fields.Float(string="Total Amount")
    treasury_id = fields.Many2one("account.treasury.forecast", string="Treasury")

class AccountTreasuryForecastMcheck(models.Model):
     #Editado por Pedro Cabrera
    _name = 'account.treasury.forecast.fund.requisition'
    _description = 'Treasury Forecast Fund Requisition'
    mcheck_id = fields.Many2one("mcheck.mcheck", string="Mcheck")
    currency_id = fields.Many2one('res.currency', string='Currency')
    date = fields.Date(string="Date")
    state = fields.Selection([('draft','Borrador'),('reject','Rechazado'),('confirmed','Esperando Aprobación'),('done','Aprobado')],readonly=True, string='Estado',default='draft')
    journal_id = fields.Many2one("account.journal", string="Journal")
    name = fields.Char(string="Name", required=False)
    reference = fields.Char(string="Reference", required=False)
    total = fields.Float(string="Amount", digits_compute=dp.get_precision('Account'))
    treasury_id = fields.Many2one("account.treasury.forecast",  string="Treasury")

    @api.multi
    def open_check(self):
    		dummy, view_id_form  = self.pool.get('ir.model.data').get_object_reference(self.env.cr, self.env.uid, 'banks', 'view_mcheck_form')
		valores = {}
		valores = dict(valores or {})
		valores.update({'doc_type': 'check' ,'journal_id': self.journal_id.id,'name': self.name, 'reference': self.reference, 'total': self.total})
		if self.mcheck_id:
			chq = self.env["mcheck.mcheck"].browse(self.mcheck_id.id)
			chq.write(valores)
			return {
				'name':_("Mchecks"),
				'view_type': 'form',
			   	'res_model': 'mcheck.mcheck',
			    	'type': 'ir.actions.act_window',
				'context': {},
				'views': [(view_id_form, 'form')],
				'nodestroy': True,
				'res_id' : self.mcheck_id.id,
			    	'target': 'current',
			    	'domain': '[]'
				}
		else:
			b = self.env["mcheck.mcheck"].create(valores)
			if b:
				self.write({'mcheck_id': b.id})
				return {
					'name':_("Mchecks"),
					'view_type': 'form',
				   	'res_model': 'mcheck.mcheck',
				    	'type': 'ir.actions.act_window',
					'context': {},
					'views': [(view_id_form, 'form')],
					'nodestroy': True,
					'res_id' : b.id,
				    	'target': 'current',
				    	'domain': '[]'
					}


"""
class AccountTreasuryForecastMcheck(models.Model):
    _name = 'account.treasury.forecast.mchecks'
    _description = 'Treasury Forecast Mchecks'
    mcheck_id = fields.Many2one("mcheck.mcheck", string="Mcheck")
    date = fields.Date(string="Date")
    journal_id = fields.Many2one("account.journal", string="Journal")
    name = fields.Char(string="Name", required=False)
    reference = fields.Char(string="Reference", required=False)
    total = fields.Float(string="Amount", digits_compute=dp.get_precision('Account'))
    treasury_id = fields.Many2one("account.treasury.forecast",  string="Treasury")
"""


class AccountTreasuryForecastSalesForecast(models.Model):
    _name = 'account.treasury.forecast.sale.forecast'
    _description = 'Treasury Forecast Sales Forecast'

    forecast_id = fields.Many2one("sale.forecast.line", string="Sales Forecast")
    product_id = fields.Many2one("product.product", string="Product")
    auto_amount = fields.Float(string="Automatic Amount", digits_compute=dp.get_precision('Account'))
    auto_quantity = fields.Float(string="Automatic Quantity", digits_compute=dp.get_precision('Account'))
    manual_amount = fields.Float(string="Manual Amount", digits_compute=dp.get_precision('Account'))
    manual_quantity = fields.Float(string="Manual Quantity", digits_compute=dp.get_precision('Account'))
    factor1 = fields.Float(string="facto1", digits_compute=dp.get_precision('Account'))
    factor2 = fields.Float(string="facto2", digits_compute=dp.get_precision('Account'))
    treasury_id = fields.Many2one("account.treasury.forecast",  string="Treasury")

class AccountTreasuryForecastInvoice(models.Model):
    _name = 'account.treasury.forecast.invoice'
    _description = 'Treasury Forecast Invoice'
    invoice_id = fields.Many2one("account.invoice", string="Invoice")
    currency_id= fields.Many2one('res.currency', string='Currency')
    date_due = fields.Date(string="Fecha de Vencimiento")
    partner_id = fields.Many2one("res.partner", string="Empresa")
    journal_id = fields.Many2one("account.journal", string="Diario")
    state = fields.Selection([('draft', 'Borrador'), ('proforma', 'Pro-forma'),
                              ('proforma2', 'Pro-forma'), ('open', 'Abierta'),
                              ('paid', 'Pagada'), ('cancel', 'Cancelada')],
                             string="State")
    base_amount = fields.Float(string="Base Amount",
                               digits_compute=dp.get_precision('Account'))
    tax_amount = fields.Float(string="Tax Amount",
                              digits_compute=dp.get_precision('Account'))
    total_amount = fields.Float(string="Total Amount",
                                digits_compute=dp.get_precision('Account'))
    residual_amount = fields.Float(string="Residual Amount",
                                   digits_compute=dp.get_precision('Account'))


class AccountTreasuryForecast(models.Model):
    _name = 'account.treasury.forecast'
    _description = 'Treasury Forecast'
    
    def get_currency(self):
		return self.env.user.company_id.currency_id.id

    currency_id = fields.Many2one("res.currency", "Moneda", domain=[('active','=',True)],default=get_currency, help="Moneda que sera utilizada para el calculo para el flujo de efectivo")
    name = fields.Char(string="Description", required=True)
    total_bank=fields.Float(string="Total en Bancos",help="Total de los bancos de la empresa en la moneda que sera calculado el flujo de efectivo")
    total_purchase=fields.Float(string="Total de Compras", help="Total de Compras que suman las ordenes de compras aprobadas y pendiente de aprobacion")
    total_funds= fields.Float(string="Total Req. Fondos", help="Total de Req.de Fondos que suman los aprobadas y pendiente de aprobacion")
    
    total_invoice_out = fields.Float(string="Pagos Pendientes", help="Totales de las facturas de proveedor pendientes de pagos")
    total_incoming= fields.Float(string="Cobros Pendientes", help="Totales de las facturas de clientes pendientes de cobro")
    totaL_recurring= fields.Float(string="Pagos Recurrentes", help="Totales de pagos recurrentes de la empresa")
    total_sale_forecast= fields.Float(string="Proyección de Ventas")
    state = fields.Selection([('draft','Borrador'),('progress','Progreso'),('done','Finalizado')], string='Estado',default='draft')
    start_date = fields.Date(string="Start Date", required=True, help="Rango de inicio de fecha, muy importante para obtener la información de los documentos para el flujo de efectivo")
    end_date = fields.Date(string="End Date", required=True,help="Rango final de fecha, muy importante para obtener la información de los documentos para el flujo de efectivo")
    check_draft = fields.Boolean(string="Draft", default=1, help="Estado borrador para los diferentes documentos que seran integrados en el flujo de efectivo")
    check_proforma = fields.Boolean(string="Esperando Aprobación", default=1, help="Estado proforma para los diferentes documentos que seran integrados en el flujo de efectivo")
    check_done = fields.Boolean(string="Aprobado", default=1, help="Estado Aprobado para los diferentes documentos que seran integrados en el flujo de efectivo")
    check_open = fields.Boolean(string="Opened", default=1, help="Estado Abierto para los diferentes documentos que seran integrados en el flujo de efectivo")
    out_invoice_ids = fields.Many2many(
        comodel_name="account.treasury.forecast.invoice",
        relation="account_treasury_forecast_out_invoice_rel",
        column1="treasury_id", column2="out_invoice_id",
        string="Out Invoices")
    in_invoice_ids = fields.Many2many(
        comodel_name="account.treasury.forecast.invoice",
        relation="account_treasury_forecast_in_invoice_rel",
        column1="treasury_id", column2="in_invoice_id",
        string="In Invoices")
    recurring_line_ids = fields.One2many(
        "account.treasury.forecast.line", "treasury_id",
        string="Recurring Lines", domain=[('line_type', '=', 'recurring')])

    #mchecks_line_ids = fields.One2many("account.treasury.forecast.mchecks", "treasury_id",string="Mchecks Lines",)
    
    sales_forecast_line_ids = fields.One2many(
        "account.treasury.forecast.sale.forecast", "treasury_id",
        string="Sales Forecast  Lines",)

    funds_req_line_ids = fields.One2many(
        "account.treasury.forecast.fund.requisition", "treasury_id",
        string="Funds Requisitions",)
    purchase_order=fields.One2many("account.treasury.forecast.purchase.order", "treasury_id",string="Purchase Order")
    total_ingresos= fields.Float(string="Total Ingresos")
    total_gastos= fields.Float(string="Total Gastos")
    diferencia_total=fields.Float(string="Diferencia")
    


    @api.one
    @api.constrains('end_date', 'start_date')
    def check_date(self):
        if self.start_date > self.end_date:
            raise exceptions.Warning(
                _('Error!:: End date is lower than start date.'))

    @api.one
    @api.constrains('check_draft', 'check_proforma', 'check_open')
    def check_filter(self):
        if not self.check_draft and not self.check_proforma and \
                not self.check_open:
            raise exceptions.Warning(
                _('Error!:: There is no any filter checked.'))

    @api.one
    def restart(self):
        self.out_invoice_ids.unlink()
        self.in_invoice_ids.unlink()
        self.funds_req_line_ids.unlink()
        self.purchase_order.unlink()
        return True

    @api.multi
    def button_calculate(self):
        self.restart()
        self.calculate_invoices()
	#self.calculate_mcheck_line()
	self.sale_forecast_line()
	self.calculate_fund_req_line()
        self.calculate_purchase_order()
	self.calculate_forecast_line()
        self.calculate_total()
        return True
  
    @api.one
    def calculate_total(self):
	self.total_ingresos = 0
	self.total_gastos = 0
   	self.diferencia_total = 0
	self.total_ingresos = self.total_incoming + self.total_sale_forecast
        self.total_gastos = self.total_purchase + self.total_funds + self.total_invoice_out + self.totaL_recurring
        self.diferencia_total = self.total_ingresos +  self.total_gastos

    @api.one
    def calculate_invoices(self):
        invoice_obj = self.env['account.invoice']
        treasury_invoice_obj = self.env['account.treasury.forecast.invoice']
        new_invoice_ids = []
        in_invoice_lst = []
        out_invoice_lst = []
        state = []
	self.total_incoming = 0
	self.total_invoice_out = 0
        if self.check_draft:
            state.append("draft")
        if self.check_proforma:
            state.append("confirmed")
        if self.check_open:
            state.append("open")
        invoice_ids = invoice_obj.search([('date_due', '>', self.start_date),
                                          ('date_due', '<', self.end_date),
                                          ('state', 'in', tuple(state))])
	print "*"*200
	print self.start_date.month
	print "*"*200
        for invoice_o in invoice_ids:
            currency  = None
	    if invoice_o.currency_id.id == self.currency_id.id:
		if invoice_o.type in ("out_invoice", "out_refund"):
                    self.total_incoming += invoice_o.amount_total
                    print self.total_incoming
                elif invoice_o.type in ("in_invoice", "in_refund"):
                    self.total_invoice_out += invoice_o.amount_total
		    print self.total_invoice_out
		    
            else:
		currency = self.currency_id.with_context(date=datetime.now())
                invoice_currency = invoice_o.currency_id.with_context(date=datetime.now())
		rate = None
		if invoice_currency.rate:
		    rate = currency.rate / invoice_currency.rate
		    if invoice_o.type in ("out_invoice", "out_refund"):
                        self.total_incoming += rate*(invoice_o.amount_total)
                    elif invoice_o.type in ("in_invoice", "in_refund"):
                        self.total_invoice_out += rate*(invoice_o.amount_total)
		else:
		    if invoice_o.type in ("out_invoice", "out_refund"):
                        self.total_incoming += invoice_o.amount_total
                    elif invoice_o.type in ("in_invoice", "in_refund"):
                        self.total_invoice_out += invoice_o.amount_total		
		
            values = {
                'invoice_id': invoice_o.id,
                'date_due': invoice_o.date_due,
                'partner_id': invoice_o.partner_id.id,
                'journal_id': invoice_o.journal_id.id,
		'currency_id':invoice_o.currency_id.id,
                'state': invoice_o.state,
                'base_amount': invoice_o.amount_untaxed,
                'tax_amount': invoice_o.amount_tax,
                'total_amount': invoice_o.amount_total,
                'residual_amount': invoice_o.residual,
            }
            new_id = treasury_invoice_obj.create(values)
            new_invoice_ids.append(new_id)
            if invoice_o.type in ("out_invoice", "out_refund"):
                out_invoice_lst.append(new_id.id)
            elif invoice_o.type in ("in_invoice", "in_refund"):
                in_invoice_lst.append(new_id.id)
        self.write({'out_invoice_ids': [(6, 0, out_invoice_lst)],
                    'in_invoice_ids': [(6, 0, in_invoice_lst)]})
        return new_invoice_ids
    """
    @api.one
    def calculate_mcheck_line(self):
	line_obj = self.env['account.treasury.forecast.mchecks']
        odmchecks_pagos = self.env['mcheck.opagos']
        new_line_ids = []
        mchecks_line_lst = odmchecks_pagos.search([('date', '>=', self.start_date),('date', '<=', self.end_date)])
        for line_o in  mchecks_line_lst:
	    if line_o.order_id.state in ['open','done']:
		    values = {	
			    'name': line_o.name,
			    'date': line_o.date,
			    'journal_id': line_o.journal_id.id,
			    'reference': line_o.reference,
			    'total': line_o.total,
			    'treasury_id': self.id,
	       	    	    }
		    new_line_id = line_obj.create(values)
		    new_line_ids.append(new_line_id)
        return new_line_ids
     """

    def calculate_fund_req_line(self):
	line_obj = self.env['account.treasury.forecast.fund.requisition']
        fund_req_pool = self.env['funds.requisition']
        new_line_ids = []
	state = []
        if self.check_proforma:
	    state.append("confirmed")
        if self.check_done:
            state.append("done")
        fund_req_list = fund_req_pool.search([('date', '>=', self.start_date),('date', '<=', self.end_date),('state', 'in', tuple(state))])  
        self.total_funds = 0
        for line_o in  fund_req_list:
	    currency  = None
	    if line_o.fund_currency.id == self.currency_id.id:
		self.total_funds += line_o.total
            else:
		currency = self.currency_id.with_context(date=datetime.now())
		funds_currency = line_o.fund_currency.with_context(date=datetime.now())		
		rate = None
		if funds_currency.rate:
		    rate = currency.rate / funds_currency.rate
				
		self.total_funds += rate*(line_o.total)
            values = {	
			'name': line_o.name,
			'date': line_o.date,
			'journal_id': line_o.journal_id.id,
			'currency_id': line_o.fund_currency.id,
			'state': line_o.state,
			'reference': line_o.reference,
			'total': line_o.total,
			'treasury_id': self.id,
	       	     }
	    new_line_id = line_obj.create(values)
	    new_line_ids.append(new_line_id)
        return new_line_ids

   
    def calculate_purchase_order(self):
	line_obj = self.env['account.treasury.forecast.purchase.order']
        purchase_order_pool = self.env['purchase.order']
        new_line_ids = []
	state = []
	self.total_purchase = 0
        if self.check_proforma:
	    state.append("confirmed")
        if self.check_done:
            state.append("done")
	    state.append("approved")
        purchase_order_list = purchase_order_pool.search([('date_order', '>=', self.start_date),('date_order', '<=', self.end_date),('state', 'in', tuple(state))])
        for line_o in  purchase_order_list:
	    currency  = None
	    if line_o.currency_id.id == self.currency_id.id:
		self.total_purchase += line_o.amount_total
            else:
		currency = self.currency_id.with_context(date=datetime.now())
		purchase_currency = line_o.currency_id.with_context(date=datetime.now())		
		rate = None
		if purchase_currency.rate:
		    rate = currency.rate / purchase_currency.rate		
		self.total_purchase += rate*(line_o.amount_total)
	    values = {	
			'purchase_id': line_o.id,
			'date_order': line_o.date_order,
			'currency_id': line_o.currency_id.id,
			'state': line_o.state,
			'source_document': line_o.origin,
			'amount_total': line_o.amount_total,
			'partner_id': line_o.partner_id.id,
			'treasury_id': self.id,
	       	     }
	    new_line_id = line_obj.create(values)
            new_line_ids.append(new_line_id)
        return new_line_ids   
    

    @api.multi
    def action_draft(self):
	self.write({'state' : 'draft'})

    @api.multi
    def action_progress(self):
	self.write({'state':'progress'})

    @api.multi
    def action_done(self):
	self.write({'state':'done'})

    @api.one
    def sale_forecast_line(self):
	line_obj = self.env['account.treasury.forecast.sale.forecast']
        sale_fore_line = self.env['sale.forecast']
        new_line_ids = []
        sales_line_lst = sale_fore_line.search([('date_from', '>=', self.start_date),('date_to', '<=', self.end_date),('state', '=', 'done')])
        
	for sale in  sales_line_lst:
		for line_o in  sale.sale_forecast_line:
		    values = {
			    'forecast_id': line_o.id,
			    'product_id': line_o.product_id.id,
			    'auto_amount': line_o.auto_amount,
			    'manual_quantity': line_o.manual_quantity,
			    'manual_amount': line_o.manual_amount,
			    'auto_quantity': line_o.auto_quantity,
			    'factor1': line_o.factor1,
			    'factor2': line_o.factor2,
			    'treasury_id': self.id,

	       	    	    }
		    new_line_id = line_obj.create(values)
		    new_line_ids.append(new_line_id)
        return new_line_ids

    @api.one
    def calculate_forecast_line(self):
        self.totaL_recurring = 0
	for line_o in self.recurring_line_ids:
            currency  = None
            if ((line_o.date > self.start_date and
                    line_o.date < self.end_date) or
                    not line_o.date):
                if line_o.currency_id.id == self.currency_id.id:
		    self.totaL_recurring += line_o.amount
		else:
		    currency = self.currency_id.with_context(date=datetime.now())
		    lines_currency = line_o.currency_id.with_context(date=datetime.now())		
		    rate = None
		    if lines_currency.rate:
		        rate = currency.rate / lines_currency.rate	
		    self.totaL_recurring += rate*(line_o.amount)

class AccountTreasuryForecastLine(models.Model):
    _name = 'account.treasury.forecast.line'
    _description = 'Treasury Forecast Line'

    name = fields.Char(string="Description", required=True)
    line_type = fields.Selection([('recurring', 'Recurring')],string="Treasury Line Type")
    date = fields.Date(string="Date", required=True)
    currency_id= fields.Many2one('res.currency', string='Currency', required=True)
    partner_id = fields.Many2one("res.partner", string="Partner")
    amount = fields.Float(string="Amount",
                          digits_compute=dp.get_precision('Account'), required=True)
    treasury_id = fields.Many2one("account.treasury.forecast",
                                  string="Treasury")
